class Tatamotors
	def features
		puts "we are Tatamotors"
	end 
end

 
suzuki=Tatamotors.new


def suzuki.features
	puts "i m suzuki"

end
suzuki.features

bolero=Tatamotors.new
bolero.features






