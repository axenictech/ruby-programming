class Lanister
 	def family
 		puts "cersi+jamie lanister"

 	end

end

class Sterk
	def family
		puts "lyana+regar tagareyen"
	end
end

l=Lanister.new
l=Sterk.new
l.family