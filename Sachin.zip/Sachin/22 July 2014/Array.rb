class Array_Exmp
	attr_reader :s1, :s2

	puts "Enter the first string"
	s1=gets

	puts "Enter the Second string"
	s2=gets

	puts s1.length-1
	puts s2.length-1

	puts s1.(0)


end