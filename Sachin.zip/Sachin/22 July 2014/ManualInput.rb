class ManualInput
		
	
	attr_reader :a, :b 
	attr_accessor :c


puts "Enter value of a"
a=gets

puts "Enter value of b"
b=gets 

c=a.to_i + b.to_i
puts "Addition of a and b = #{c}"

end






