class Task
	
	a="abc"
	b="xyz"

	for i in 0..2
		printf a[i].chr+b[i].chr
	end
	puts"\n"
end